/* File        : boolean.h */
/* Deskripsi   : header file untuk menangani type boolean */
/* Dibuat oleh : Ade Chandra Nugraha/ 23501004 */
/* Tanggal     : 06-09-2001 */

#ifndef boolean_H
#define boolean_H
#define true 1
#define false 0
#define boolean unsigned char
#endif